A Pen created at CodePen.io. You can find this one at https://codepen.io/billyysea/pen/CHmiE.

 The first 2 are designed with depth and lighting, while the 3rd one is flatly designed with a somewhat "gooey"-ish transition on it.