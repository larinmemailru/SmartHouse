A Pen created at CodePen.io. You can find this one at http://codepen.io/AndyW/pen/twGuj.

 As in the title - visually simple animated form checkboxes