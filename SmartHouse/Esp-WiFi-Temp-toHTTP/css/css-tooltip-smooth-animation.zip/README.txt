A Pen created at CodePen.io. You can find this one at http://codepen.io/linux/pen/xrEjaK.

 Omar Dsoky Created  ' CSS ToolTip  '  with smooth animation